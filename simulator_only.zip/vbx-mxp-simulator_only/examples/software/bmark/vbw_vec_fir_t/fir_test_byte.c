/*
 * Byte compilation unit for FIR test
 */

#define VBX_TEMPLATE_T VBX_BYTESIZE_DEF
#define TEST_NAME      int8_t_fir_test

#include "fir_test_template.h"
