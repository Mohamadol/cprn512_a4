/*
 * Unsigned half compilation unit for FIR test
 */

#define VBX_TEMPLATE_T VBX_UHALFSIZE_DEF
#define TEST_NAME      uint16_t_fir_test

#include "fir_test_template.h"
