#ifndef VECTORBLOX_MXP_ORCA_H
#define VECTORBLOX_MXP_ORCA_H
#ifdef __cpluplus
extern "C" {
#endif

	int VectorBlox_MXP_Initialize();

#ifdef __cpluplus
}
#endif
#endif //VECTORBLOX_MXP_ORCA_H
