#ifndef VECTORBLOX_MXP_HPS_H
#define VECTORBLOX_MXP_HPS_H
#ifndef SYSTEM_HEADER
#define SYSTEM_HEADER "system.h"
#endif

int VectorBlox_MXP_Initialize();

#endif //VECTORBLOX_MXP_HPS_H
